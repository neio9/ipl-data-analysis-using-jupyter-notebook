# ipl_cricket_analysis
Analysing whole Ipl tournament..
Hii I'm Harsh Durugkar CS Student.
I'm Creating This EDA on Ipl 2017
Pls Check Out How's it.
 
